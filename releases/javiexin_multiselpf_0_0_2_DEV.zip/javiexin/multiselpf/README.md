# multiselpf
Multi Selection Profile Field type

Adds the option to have Multi Selection profile fields

This is a port of the 3.0 mod found here: https://www.phpbb.com/customise/db/mod/mspf/
<b>Please note:</b>
This GitHub repository is just for sharing purposes. <b style="color:red;">DO NOT install this extension from here.</b>

